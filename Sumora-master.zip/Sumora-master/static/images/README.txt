LOGO INSTRUCTIONS

Please place your Sumora by Kauzway.ai logo in this directory with the filename "logo.png".

The recommended logo specifications are:
- File format: PNG with transparency
- Resolution: At least 200x200 pixels
- Aspect ratio: Square or slightly horizontal rectangle
- Colors: Should match the updated color scheme (primary: #3f51b5, secondary: #6573c3, accent: #ff9800)

Once you add the logo file, it will automatically appear in the header and footer of the application.
